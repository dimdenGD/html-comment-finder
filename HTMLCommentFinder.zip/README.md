# HTML Comment Finder
Browser extension to find HTML comments on pages. Useful if you visit obscure sites and don't want to miss any secrets.  
Will become red and show number if there are comments and green if there's none.  
  
![screenshot](https://lune.dimden.dev/14a7b0587d.png)  